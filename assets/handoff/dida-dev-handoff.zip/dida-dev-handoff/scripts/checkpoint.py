#!/usr/bin/env python3
import argparse,json,sys,urllib.request,urllib.error
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--key',required=True);p.add_argument('--task-id');p.add_argument('--title');p.add_argument('--file');p.add_argument('--read',action='store_true');a=p.parse_args()
secret=(Path(__file__).resolve().parents[1]/'.bridge-token').read_text().strip()
def call(body):
 req=urllib.request.Request('http://127.0.0.1:18768/handoff',data=json.dumps(body,ensure_ascii=False).encode(),headers={'Authorization':'Bearer '+secret,'Content-Type':'application/json'},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=60) as r: d=json.load(r)
 except urllib.error.HTTPError as e:
  try: d=json.loads(e.read())
  except Exception: d={'ok':False,'error':'http_'+str(e.code)}
 if not d.get('ok'): raise RuntimeError(d.get('error','handoff_failed'))
 return d
body={'operation':'read','key':a.key,'task_id':a.task_id};old=call(body)
if a.read:
 print(json.dumps(old,ensure_ascii=False));sys.exit(0)
if not a.file: p.error('--file required for checkpoint')
content=Path(a.file).read_text();body.update(operation='checkpoint',base_hash=old['base_hash'],content=content,title=a.title)
result=call(body);print(json.dumps(result,ensure_ascii=False))
