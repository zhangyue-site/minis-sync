# 手机内置接入
应用启动会真正导入此Skill并启用默认交接提示。本地桥只绑定127.0.0.1:18768；每次安装随机口令保存在本Skill目录的.bridge-token，不能打印。云端只接受本人既有同步账号。
先把交接写入项目文档，然后执行：
python3 /var/minis/skills/dida-dev-handoff/scripts/checkpoint.py --key <稳定任务键> --task-id <已有ID> --file <本地交接路径>
第一次新建任务可省略task-id，增加 --title "项目｜交付动作"。脚本先读远端取得内容hash，再更新同一块并读回验证。只读对账加 --read。
未登录请打开原应用同步账号页面；沿用既有预制本人账号，不新建身份。模型设置中的ZCode API与OpenCode Go会消耗既有套餐，不能标成闲时免费。OpenCode Free只接受Free白名单，账户未配置或额度不可用会报错，不退到付费。
ZCode账号权益请本人从 https://erweima.zhangyue.site/zcode-login 登录官方客户端；官方闲时任务有单独资格及队列条件。OpenCode官方 https://opencode.ai/auth 。只通过官方登录/授权，不能把微信本地会话或密码复制给桥服务。
