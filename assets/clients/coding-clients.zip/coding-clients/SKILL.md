---
name: coding-clients
description: 在Minis自己的终端运行内置官方OpenCode与ZCode客户端，跨客户端接力开发任务及滴答交接；用于用户要求使用这两个客户端时。
---
# 内置开发客户端

本机终端有官方 `opencode` 与 `zcode`。先执行 `opencode --version`、`zcode --version` 检查资源安装完成，不以API代理或服务端运行代替手机客户端。

在项目目录执行 `opencode run "任务"`；已有会话可用官方CLI的会话参数恢复。默认仅选官方Free模型，限流或模型失效时保留本地交接并报告，不自动切付费。

ZCode首次执行 `zcode login bigmodel --no-browser`，把官方登录链接交给用户在系统浏览器完成。用户输入凭据/验证码，不把令牌粘贴到聊天。登录成功后执行 `zcode --cwd <项目路径> -p "任务" --json`。CLI运行可用不代表享有官方闲时免费。

开始、接手和交出时读取 `/var/minis/skills/dida-dev-handoff/SKILL.md`，沿用项目既有滴答ID/稳定任务键；核对真实代码差异。客户端负责文件修改和测试，真实读回后才报告滴答已更新。保存客户端session ID、已运行命令和进程状态，防止切换后重复执行。不同客户端不要同时改同一文件。

此功能在手机本地Alpine执行，不是把整份工作区发送给维护者服务器。凭据由客户端在当前安装的私有home保存，APK不含个人凭据；已有用户配置优先。
